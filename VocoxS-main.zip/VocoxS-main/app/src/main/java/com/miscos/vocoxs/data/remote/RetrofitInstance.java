package com.miscos.vocoxs.data.remote;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitInstance {
    public static String BASE_URL1="http://miscos.in/compus/";
    public static String BASE_URL="http://miscos.in/compus/api/";
    private static Retrofit retrofit;
    private static Retrofit retrofit1;

    public static Retrofit getApiClient() {
        if (retrofit == null) {
            retrofit = buildRetrofit(BASE_URL);
        }
        return retrofit;
    }

    public static Retrofit getApiClient1() {
        if (retrofit1 == null) {
            retrofit1 = buildRetrofit(BASE_URL1);
        }
        return retrofit1;
    }

    public static ApiInterface apiInterface() {
        if (retrofit1 == null) {
            retrofit1 = buildRetrofit(BASE_URL1);
        }
        return retrofit1.create(ApiInterface.class);
    }

    private static Retrofit buildRetrofit(String baseUrl) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .protocols(Arrays.asList(Protocol.HTTP_1_1))
                .readTimeout(2, TimeUnit.MINUTES)
                .retryOnConnectionFailure(true)
                .writeTimeout(2, TimeUnit.MINUTES)
                .addInterceptor(chain -> {
                    Request original = chain.request();
                    Request.Builder requestBuilder = original.newBuilder()
                            .header("Cache-Control", "no-cache");
                    Request request = requestBuilder.build();
                    return chain.proceed(request);
                })
                .connectTimeout(2, TimeUnit.MINUTES)
                .build();

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(client)
                .build();
    }

}
