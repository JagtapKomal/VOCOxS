package com.miscos.vocoxs.data.remote;

import com.miscos.vocoxs.StateData;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {
    @GET("get_states.php")
    Call<StateData.StateResponse> getState();
}
