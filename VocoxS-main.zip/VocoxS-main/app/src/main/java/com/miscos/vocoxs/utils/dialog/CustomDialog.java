package com.miscos.vocoxs.utils.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.miscos.vocoxs.databinding.CustomDialogBinding;

import java.util.Objects;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class CustomDialog extends Dialog {
    CustomDialogBinding customDialogBinding;
    @SuppressLint("SetTextI18n")
    public CustomDialog(Context context, int iconResId, String title, String message, String apiNo, String apiVersion, View.OnClickListener onClickListener) {
        super(context);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialogBinding = CustomDialogBinding.inflate(LayoutInflater.from(context));
        setContentView(customDialogBinding.getRoot());

        customDialogBinding.dialogImg.setImageResource(iconResId);
        customDialogBinding.dialogTitle.setText(title);
        customDialogBinding.dialogMsg.setText(message);
        customDialogBinding.apiNo.setText("Api No: "+apiNo);
        customDialogBinding.apiVersion.setText("Api Version: "+apiVersion);
        customDialogBinding.dialogOkBtn.setOnClickListener(onClickListener);
        customDialogBinding.dialogClose.setOnClickListener(view -> dismiss());

        Window window = getWindow();
        if (window != null) {
            WindowManager.LayoutParams layoutParams = window.getAttributes();
            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(layoutParams);
        }

        show();
    }

    public static SweetAlertDialog createProgressDialog(Context context) {
        SweetAlertDialog progressDialog = new SweetAlertDialog(context, SweetAlertDialog.PROGRESS_TYPE);
        progressDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        progressDialog.setTitleText("Loading..");
        progressDialog.setCancelable(false);
        return progressDialog;
    }
}
