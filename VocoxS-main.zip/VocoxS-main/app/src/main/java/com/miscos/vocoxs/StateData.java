package com.miscos.vocoxs;

import java.io.Serializable;
import java.util.ArrayList;

public class StateData {
    private String state_title;
    private String state_id;

    public void setstate_title(String state_title) {
        this.state_title = state_title;
    }

    public String getState_id() {
        return state_id;
    }

    public void setState_id(String state_id) {
        this.state_id = state_id;
    }

    public String getstate_title() {
        return state_title;
    }

    @Override
    public String toString() {
        return state_title;
    }

    public class StateResponse implements Serializable {
        private int error_code;
        private String message;
        private ArrayList<StateData> data;

        public int getError_code() {
            return error_code;
        }

        public String getMessage() {
            return message;
        }

        public ArrayList<StateData> getData() {
            return data;
        }
    }
}
