package com.miscos.vocoxs.maindashboard.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.miscos.vocoxs.R;
import com.miscos.vocoxs.databinding.FragmentMainDashBoardBinding;
import com.miscos.vocoxs.databinding.FragmentSplashBinding;

public class MainDashBoardFragment extends Fragment {
    FragmentMainDashBoardBinding mainDashBoardBinding;
    public MainDashBoardFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mainDashBoardBinding = FragmentMainDashBoardBinding.inflate(inflater, container, false);


        return mainDashBoardBinding.getRoot();
    }


}